package com.fujitsu.ph.junit.exercise3;

import static org.junit.Assert.*;

import org.junit.Test;

public class PhoneFormatterTest {

    @Test
    public void testFormat_LengthIs11() {
        fail("Not yet implemented");
    }

    @Test
    public void testFormat_LengthIs12() {
        fail("Not yet implemented");
    }

    @Test
    public void testFormat_IsNull() {
        fail("Not yet implemented");
    }

    @Test
    public void testFormat_LengthIsNot11And12() {
        fail("Not yet implemented");
    }

}
