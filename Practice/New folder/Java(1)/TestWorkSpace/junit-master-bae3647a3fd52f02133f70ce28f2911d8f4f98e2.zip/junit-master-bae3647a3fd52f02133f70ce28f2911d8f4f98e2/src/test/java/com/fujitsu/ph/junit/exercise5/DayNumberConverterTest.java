package com.fujitsu.ph.junit.exercise5;

import static org.junit.Assert.*;

import org.junit.Test;

public class DayNumberConverterTest {

    @Test
    public void testGetDay_01() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetDay_02() {
        fail("Not yet implemented");
    }

}
