package com.fujitsu.intarfrm.skeletons.commons.framework;

/**
 * Facadeクラスの共通親クラス
 * 
 * @author INTARFRM
 */
public abstract class IfmFacadeBase {	
}