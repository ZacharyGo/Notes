import pygame
import os
from VariableConstants import *
from Functions import *

# bomber_stop = 10

pygame.font.init()
pygame.mixer.init()

def main():
    pygame.display.set_caption("Kaboom")
    bomber = pygame.Rect(30, 10, BOMBER_WIDTH, BOMBER_HEIGHT)
    add_bucket(buckets)
    add_bucket(buckets)
    add_bucket(buckets)
    # bombs = []
    # bomber_info.next_stop = random.randint(0, WIDTH - BOMBER_WIDTH)        
    bomber_info.next_stop = 30        
    
    run = True
    clock = pygame.time.Clock()
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                
            # if event.type == pygame.KEYDOWN:
            #     if event.key == pygame.K_UP:
            #         print("Keyup")
            #         add_bucket(buckets)
            
            #     if event.key == pygame.K_DOWN:
            #         print("Keydown")
            #         remove_bucket(buckets)
                
        keys_pressed = pygame.key.get_pressed()
        handle_bombs()
        if len(buckets)==0:
            GAMEOVER_FONT = pygame.font.SysFont('arial', 100)
            draw_text = GAMEOVER_FONT.render("Game Over!!!", 1, RED)
            WIN.blit(draw_text, ((WIDTH- draw_text.get_width())//2, (HEIGHT-draw_text.get_height())//2))
            pygame.display.update() 
            run=False   
            time.sleep(5)
            break
        bucket_handle_movement(keys_pressed, buckets)
        handle_bomber_movement()
        # draw_window(bomber, buckets)
        draw_window(buckets)
    print(bombs)
    pygame.quit()
    # main()
    
    
if __name__ == "__main__":
    main()