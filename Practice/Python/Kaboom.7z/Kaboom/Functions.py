from VariableConstants import *
import random
import time

# def draw_window(bomber, buckets):
def draw_window(buckets):
    WIN.blit(BACKGROUND, (0,0))
    WIN.blit(BOMBER, bomber)


    for bucket in buckets:
        WIN.blit(BUCKET, bucket)
    if len(bombs)> 0:
        for bomb in bombs:
            # print(bomb)        
            if bombs_explode:
                explode = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'Explode1.png')), (BOMBS_WIDTH, BOMBS_HEIGHT))
                WIN.blit(explode, bomb)
                pygame.display.update()                
                time.sleep(0.5)
            else:
                WIN.blit(BOMB, bomb)
                
    if bombs_explode:
        bombs.clear()    
    pygame.display.update()
    
def bucket_handle_movement(keys_pressed, buckets):
    for bucket in buckets:
        if keys_pressed[pygame.K_LEFT] and bucket.x > 0 + BUCKET_VEL:
            bucket.x -= BUCKET_VEL
            print("KeyLeft")
            
        if keys_pressed[pygame.K_RIGHT] and bucket.x < WIDTH - (BUCKET_WIDTH + BUCKET_VEL):
            bucket.x += BUCKET_VEL
            print("KeyRight")
     

def handle_bomber_movement():    
    if bomber.x > bomber_info.next_stop : # bomber should move left
        if (len(bomber_info.location_to_drop) > 0) and (bomber.x <= bomber_info.location_to_drop[0]):
            # print("dropping at:", bomber.x)
            drop_bombs()
            
            
        if bomber.x - bomber_info.speed < bomber_info.next_stop: # if it will exceed the next stop
            bomber.x = bomber_info.next_stop
        else :
            bomber.x -=bomber_info.speed
            
    elif bomber.x < bomber_info.next_stop: # bomber should move right
        if (len(bomber_info.location_to_drop) > 0) and (bomber.x >= bomber_info.location_to_drop[0]):
            # print("dropping at:", bomber.x)
            drop_bombs()
            
            
        if bomber.x + bomber_info.speed > bomber_info.next_stop: # if it will exceed the next stop
            bomber.x = bomber_info.next_stop
        else :
            bomber.x += bomber_info.speed
            
    elif bomber.x == bomber_info.next_stop : 
        if (len(bomber_info.location_to_drop) > 0):
            # print("dropping at:", bomber.x)
            drop_bombs()
            
        bomber_info.next_stop = random.randint(0, WIDTH - BOMBER_WIDTH) # Set where bomber will stop next
        bomber_info.speed = random.randint(10, bomber_info.current_max_speed) # Set bomber speed randomly
        bomb_number = 0
        bomber_info.location_to_drop = []
        bomb_distance = (bomber_info.next_stop - bomber.x) // bomber_info.bombs_to_drop
        while bomb_number < bomber_info.bombs_to_drop:
            bomb_number +=1
            bomber_info.location_to_drop.append(bomber.x + (bomb_number * bomb_distance))
            # print("bomb location", bomber_info.location_to_drop[bomb_number - 1])
        bomber_info.location_to_drop[bomb_number - 1] = bomber_info.next_stop # Prevent droping after next stop
        # print ("current location", bomber.x, "next Stop", bomber_info.next_stop, ", Speed: ", bomber_info.speed)
        # print("-----------------------------------")
        pass
        
def drop_bombs():
    bomb = pygame.Rect(bomber_info.location_to_drop[0], bomber.y + bomber.height, BOMBS_WIDTH, BOMBS_HEIGHT)
    bombs.append(bomb)
    bomber_info.location_to_drop.pop(0)
    
    
        
# def handle_bombs(bombs, buckets):
def handle_bombs():
    # Loop all bombs
    for bomb in bombs:
        bomb.y += BOMB_VEL
        for bucket in buckets:
            if bucket.colliderect(bomb):
                bombs.remove(bomb)
                break
                bucket_catch()        
        if (bomb.y + BOMBS_HEIGHT>=HEIGHT):
            handle_bomb_explode()            
    # remove and add point if bomb collied buckets 
    # Explode all bombs if 1 bomb hits bottom
    pass

def handle_bomb_explode():
    WIN.blit(HAPPY_BOMBER, bomber)
    
    for bomb in bombs:
        explode_bomb('Explode1.png', bomb)
        explode_bomb('Explode2.png', bomb)
        explode_bomb('Explode3.png', bomb)
    bombs.clear()
    remove_bucket(buckets)
    
    
    # WIN.blit(BOMBER, bomber)
    # pygame.display.update()                
    
def explode_bomb(explodefile, bomb):
    explode = pygame.transform.scale(pygame.image.load(os.path.join('Images', explodefile)), (BOMBS_WIDTH, BOMBS_HEIGHT))
    WIN.blit(explode, bomb)
    pygame.display.update()                
    time.sleep(0.1)
    
def add_bucket(buckets):
    bucket_count = len(buckets)
    # print(bucket_count)
    if bucket_count == 0:
        bucket = pygame.Rect(0, HEIGHT-((BUCKET_HEIGHT + BUCKET_DISTANCE) * 3), BUCKET_WIDTH, BUCKET_HEIGHT)
    else:        
        bucket = pygame.Rect(buckets[bucket_count-1].x, buckets[bucket_count-1].y + BUCKET_HEIGHT + BUCKET_DISTANCE,
                BUCKET_WIDTH, BUCKET_HEIGHT)
        
    buckets.append(bucket)
    
def remove_bucket(buckets):
    print("Removing")
    buckets.pop()

def bucket_catch():
    pass