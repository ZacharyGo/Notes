from classes import *
import pygame
import os
WIDTH, HEIGHT = 1200, 500


WIN = pygame.display.set_mode((WIDTH, HEIGHT))
FPS = 60
BUCKET_WIDTH, BUCKET_HEIGHT = 100, 50
BUCKET_DISTANCE = 10
BUCKET_VEL = 80
BOMBS_WIDTH, BOMBS_HEIGHT = 50, 50
BOMB_VEL = 5
BOMBER_WIDTH, BOMBER_HEIGHT = 100, 100
BOMBER_MAX_SPEED = 10
RED = (255, 0, 0)
# BORDER = pygame.Rect(WIDTH//2 - 5, 0, 10, HEIGHT)
BACKGROUND = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'Background.png')), (WIDTH, HEIGHT))
BOMBER = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'bomber1.png')), (BOMBER_WIDTH, BOMBER_HEIGHT))
HAPPY_BOMBER = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'bomber2.png')), (BOMBER_WIDTH, BOMBER_HEIGHT))
BOMB = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'bomb1.png')), (BOMBS_WIDTH, BOMBS_HEIGHT))
BUCKET = pygame.transform.scale(pygame.image.load(os.path.join('Images', 'Bucket1.png')), (BUCKET_WIDTH, BUCKET_HEIGHT))

bomber = pygame.Rect(30, 10, BOMBER_WIDTH, BOMBER_HEIGHT)
bomber_info = BomberClass()

bombs = []
bombs_explode = False
buckets= []

# apple
