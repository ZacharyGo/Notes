class BomberClass:
    next_stop = 35       
    current_max_speed=100
    speed=10
    max_speed=100
    bombs_to_drop = 1
    location_to_drop = []