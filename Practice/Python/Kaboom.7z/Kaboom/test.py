from classes import *

# bomber_movement = {"next_stop":10, "current_max_speed":10, "max_speed":10}

def main():
    mybomber = BomberClass()
    if mybomber.next_stop == 10:
        mybomber.next_stop = 100
    print(mybomber.next_stop)
if __name__ == "__main__":
    main()
    