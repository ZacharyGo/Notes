package com.linkedin.collectibles.BigStarCollectibles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BigStarCollectiblesApplication {

	public static void main(String[] args) {
		SpringApplication.run(BigStarCollectiblesApplication.class, args);
	}

}
