﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormPractice
{
    
    public partial class Exercise1 : Form
    {

        public Exercise1()
        {
            InitializeComponent();
        }
    }
    class MyStruct
    {
        public string Name { get; set; }
        public string Adres { get; set; }


        public MyStruct(string name, string adress)
        {
            Name = name;
            Adres = adress;
        }


    }
    List<MyStruct> list = new List<MyStruct> { new MyStruct("fff", "b"), new MyStruct("c", "d") };
}
