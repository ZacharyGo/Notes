﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VideoSurveillanceExerciseForms.Exercises
{
    class Exercise1
    {
        

        public Exercise1()
        {
            Panel panel1 = Application.OpenForms["Form1"].Controls["panel1"] as Panel;
            DataGridView dataGridView = panel1.Controls["dataGridView1"] as DataGridView;
            panel1.Visible = true;

            
            //var source = new BindingSource();
            //source.DataSource = scores;
            //dataGridView.DataSource = source;
            //dataGridView.Visible = true;
        }
    }

}
