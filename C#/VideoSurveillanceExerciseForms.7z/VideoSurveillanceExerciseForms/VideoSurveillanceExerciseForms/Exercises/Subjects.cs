﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VideoSurveillanceExerciseForms.Exercises
{
    public class Subjects
    {
        public string Subject { get; set; }
        public int Score { get; set; }


        //public Subjects(string subject, int score)
        //{
        //    Subject = subject;
        //    Score = score;
        //}
    }
}
