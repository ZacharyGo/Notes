﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using VideoSurveillanceExerciseForms.Exercises;

namespace VideoSurveillanceExerciseForms
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        

    

        private void exercise1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Exercise1 exercise1 = new Exercise1();
        }
    }
    public class Subjects
    {
        public string Subject { get; set; }
        public int Score { get; set; }


        //public Subjects(string subject, int score)
        //{
        //    Subject = subject;
        //    Score = score;
        //}


    }
}
