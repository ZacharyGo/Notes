﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtAdultTicket = New System.Windows.Forms.TextBox()
        Me.txtAdultPrice = New System.Windows.Forms.TextBox()
        Me.txtChildrenPrice = New System.Windows.Forms.TextBox()
        Me.txtChildrenTicket = New System.Windows.Forms.TextBox()
        Me.txtGrossAmount = New System.Windows.Forms.TextBox()
        Me.txtTotalTicket = New System.Windows.Forms.TextBox()
        Me.txtAmountDonated = New System.Windows.Forms.TextBox()
        Me.txtPercentage = New System.Windows.Forms.TextBox()
        Me.txtChildernAmount = New System.Windows.Forms.TextBox()
        Me.txtAdultAmount = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.Location = New System.Drawing.Point(20, 119)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 50)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Adult"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(20, 181)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(169, 50)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Children"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(20, 244)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 50)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Gross"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(469, 59)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(127, 50)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Ticket"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(657, 59)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(109, 50)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Price"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(20, 306)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(395, 50)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Percentage to donate"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(20, 369)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(409, 50)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Total amount donated"
        '
        'txtAdultTicket
        '
        Me.txtAdultTicket.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtAdultTicket.Location = New System.Drawing.Point(453, 112)
        Me.txtAdultTicket.Name = "txtAdultTicket"
        Me.txtAdultTicket.Size = New System.Drawing.Size(149, 57)
        Me.txtAdultTicket.TabIndex = 7
        Me.txtAdultTicket.Text = "0"
        Me.txtAdultTicket.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAdultPrice
        '
        Me.txtAdultPrice.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtAdultPrice.Location = New System.Drawing.Point(633, 112)
        Me.txtAdultPrice.Name = "txtAdultPrice"
        Me.txtAdultPrice.Size = New System.Drawing.Size(149, 57)
        Me.txtAdultPrice.TabIndex = 8
        Me.txtAdultPrice.Text = "0"
        Me.txtAdultPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtChildrenPrice
        '
        Me.txtChildrenPrice.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtChildrenPrice.Location = New System.Drawing.Point(633, 174)
        Me.txtChildrenPrice.Name = "txtChildrenPrice"
        Me.txtChildrenPrice.Size = New System.Drawing.Size(149, 57)
        Me.txtChildrenPrice.TabIndex = 10
        Me.txtChildrenPrice.Text = "0"
        Me.txtChildrenPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtChildrenTicket
        '
        Me.txtChildrenTicket.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtChildrenTicket.Location = New System.Drawing.Point(453, 174)
        Me.txtChildrenTicket.Name = "txtChildrenTicket"
        Me.txtChildrenTicket.Size = New System.Drawing.Size(149, 57)
        Me.txtChildrenTicket.TabIndex = 9
        Me.txtChildrenTicket.Text = "0"
        Me.txtChildrenTicket.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtGrossAmount
        '
        Me.txtGrossAmount.BackColor = System.Drawing.SystemColors.Control
        Me.txtGrossAmount.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtGrossAmount.Enabled = False
        Me.txtGrossAmount.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtGrossAmount.Location = New System.Drawing.Point(816, 237)
        Me.txtGrossAmount.Name = "txtGrossAmount"
        Me.txtGrossAmount.Size = New System.Drawing.Size(149, 50)
        Me.txtGrossAmount.TabIndex = 12
        Me.txtGrossAmount.Text = "0"
        Me.txtGrossAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTotalTicket
        '
        Me.txtTotalTicket.BackColor = System.Drawing.SystemColors.Control
        Me.txtTotalTicket.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtTotalTicket.Enabled = False
        Me.txtTotalTicket.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtTotalTicket.Location = New System.Drawing.Point(453, 237)
        Me.txtTotalTicket.Name = "txtTotalTicket"
        Me.txtTotalTicket.Size = New System.Drawing.Size(149, 50)
        Me.txtTotalTicket.TabIndex = 11
        Me.txtTotalTicket.Text = "0"
        Me.txtTotalTicket.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAmountDonated
        '
        Me.txtAmountDonated.BackColor = System.Drawing.SystemColors.Control
        Me.txtAmountDonated.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.txtAmountDonated.Enabled = False
        Me.txtAmountDonated.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtAmountDonated.Location = New System.Drawing.Point(816, 362)
        Me.txtAmountDonated.Name = "txtAmountDonated"
        Me.txtAmountDonated.Size = New System.Drawing.Size(149, 50)
        Me.txtAmountDonated.TabIndex = 21
        Me.txtAmountDonated.Text = "0"
        Me.txtAmountDonated.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtPercentage
        '
        Me.txtPercentage.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtPercentage.Location = New System.Drawing.Point(816, 299)
        Me.txtPercentage.Name = "txtPercentage"
        Me.txtPercentage.Size = New System.Drawing.Size(149, 57)
        Me.txtPercentage.TabIndex = 20
        Me.txtPercentage.Text = "0"
        Me.txtPercentage.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtChildernAmount
        '
        Me.txtChildernAmount.Enabled = False
        Me.txtChildernAmount.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtChildernAmount.Location = New System.Drawing.Point(816, 174)
        Me.txtChildernAmount.Name = "txtChildernAmount"
        Me.txtChildernAmount.Size = New System.Drawing.Size(149, 57)
        Me.txtChildernAmount.TabIndex = 18
        Me.txtChildernAmount.Text = "0"
        Me.txtChildernAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtAdultAmount
        '
        Me.txtAdultAmount.Enabled = False
        Me.txtAdultAmount.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.txtAdultAmount.Location = New System.Drawing.Point(816, 112)
        Me.txtAdultAmount.Name = "txtAdultAmount"
        Me.txtAdultAmount.Size = New System.Drawing.Size(149, 57)
        Me.txtAdultAmount.TabIndex = 17
        Me.txtAdultAmount.Text = "0"
        Me.txtAdultAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(813, 59)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(163, 50)
        Me.Label8.TabIndex = 16
        Me.Label8.Text = "Amount"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Segoe UI", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(960, 302)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(52, 50)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "%"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1160, 450)
        Me.Controls.Add(Me.txtAmountDonated)
        Me.Controls.Add(Me.txtPercentage)
        Me.Controls.Add(Me.txtChildernAmount)
        Me.Controls.Add(Me.txtAdultAmount)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtGrossAmount)
        Me.Controls.Add(Me.txtTotalTicket)
        Me.Controls.Add(Me.txtChildrenPrice)
        Me.Controls.Add(Me.txtChildrenTicket)
        Me.Controls.Add(Me.txtAdultPrice)
        Me.Controls.Add(Me.txtAdultTicket)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label9)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtAdultTicket As TextBox
    Friend WithEvents txtAdultPrice As TextBox
    Friend WithEvents txtChildrenPrice As TextBox
    Friend WithEvents txtChildrenTicket As TextBox
    Friend WithEvents txtGrossAmount As TextBox
    Friend WithEvents txtTotalTicket As TextBox
    Friend WithEvents txtAmountDonated As TextBox
    Friend WithEvents txtPercentage As TextBox
    Friend WithEvents txtChildernAmount As TextBox
    Friend WithEvents txtAdultAmount As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
End Class
