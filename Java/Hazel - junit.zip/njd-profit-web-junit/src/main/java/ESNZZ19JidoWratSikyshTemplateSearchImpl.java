/*
 * Copyright 2017 FUJITSU LIMITED. All rights reserved.
 *
 * 更新履歴
 * 2018/09/19  FJ)FUJITSU  自動生成
 */
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.alsok.njd.fw.common.entity.sql.OrderByList;
import jp.co.alsok.njd.fw.common.entity.sql.SqlOperator;
import jp.co.alsok.njd.fw.common.entity.sql.SqlOrderBy;
import jp.co.alsok.njd.fw.common.entity.sql.WhereList;
import jp.co.alsok.njd.fw.common.exception.NjdBusinessException;
import jp.co.alsok.njd.fw.common.message.NjdResultMessages;
import jp.co.alsok.njd.fw.common.util.collection.NjdCollectionUtils;
import jp.co.alsok.njd.fw.common.util.string.NjdStringUtils;
import jp.co.alsok.njd.profit.common.condition.CN_BUNKATSUZUMI_FLG;
import jp.co.alsok.njd.profit.common.condition.CN_CHK_KIYK_RYKN_KIZK_SIKY_KBN;
import jp.co.alsok.njd.profit.common.condition.CN_GASSANSAKI_FLG;
import jp.co.alsok.njd.profit.common.condition.CN_JIDO_WARIATE_FLG;
import jp.co.alsok.njd.profit.common.condition.CN_KEIYAKU_RYOKIN_SEIKYUSAKI_KBN;
import jp.co.alsok.njd.profit.common.condition.CN_SIKYSH_TEMPLATE_SHNSI_JKY_KBN;
import jp.co.alsok.njd.profit.common.condition.CN_X_JIDO_WARIATE_SHORI_KBN;
import jp.co.alsok.njd.profit.common.entity.ED3501T_TBL;
import jp.co.alsok.njd.profit.common.entity.ED3501T_TBLColumn;
import jp.co.alsok.njd.profit.common.entity.ED3501T_TBLService;
import jp.co.alsok.njd.profit.common.entity.ED3503T_TBL;
import jp.co.alsok.njd.profit.common.entity.ED3503T_TBLColumn;
import jp.co.alsok.njd.profit.common.entity.ED3503T_TBLService;
import jp.co.alsok.njd.profit.common.entity.ED3969M_TBL;
import jp.co.alsok.njd.profit.common.entity.ED3969M_TBLColumn;
import jp.co.alsok.njd.profit.common.entity.ED3969M_TBLService;
import jp.co.alsok.njd.profit.common.message.NjdMessageId;
import jp.co.alsok.njd.profit.domain.SN.ESNZZ19.ESNZZ19JidoWratSikyshTemplateSearchInDTO;
import jp.co.alsok.njd.profit.domain.SN.ESNZZ19.ESNZZ19JidoWratSikyshTemplateSearchOutDTO;
import lombok.extern.slf4j.Slf4j;

/**
 * <p>
 * 共通サービス「自動割当請求書テンプレート検索」の実装クラスです。
 * </p>
 *
 * @author FUJITSU
 */
@Service
@Slf4j
public class ESNZZ19JidoWratSikyshTemplateSearchImpl{

    /** 請求情報契約管理テーブルのテーブルサービスです */
    @Autowired
    private ED3501T_TBLService ed3501t;

    /** 請求管理明細テーブルのテーブルサービスです */
    @Autowired
    private ED3503T_TBLService ed3503t;

    /** 請求書テンプレートマスタのテーブルサービスです */
    @Autowired
    private ED3969M_TBLService ed3969m;


    protected void validate(ESNZZ19JidoWratSikyshTemplateSearchInDTO inDto) {

        // 必須項目入力チェック
        if (NjdStringUtils.isEmpty(inDto.getKaishaCd()) || NjdStringUtils.isEmpty(inDto.getXJidoWariateShoriKbn())) {
            throw new NjdBusinessException(NjdResultMessages.fromId(NjdMessageId.EM_ZZ9998E));
        }

    }


    protected ESNZZ19JidoWratSikyshTemplateSearchOutDTO doExecute(ESNZZ19JidoWratSikyshTemplateSearchInDTO inDto) {

        ESNZZ19JidoWratSikyshTemplateSearchOutDTO outDto = new ESNZZ19JidoWratSikyshTemplateSearchOutDTO();

        // 処理パターン別パラメータチェック
        if ((NjdStringUtils.equals(inDto.getXJidoWariateShoriKbn(), CN_X_JIDO_WARIATE_SHORI_KBN.JIDOWARIATE_SETTEI_RIYO.getValue())
            || NjdStringUtils.equals(inDto.getXJidoWariateShoriKbn(), CN_X_JIDO_WARIATE_SHORI_KBN.KEIYAKU_SEIKYU_YOTEI_TOKUTEI.getValue()))
            && NjdStringUtils.isEmpty(inDto.getKanrenJuchuKeiyakuNo())) {
            throw new NjdBusinessException(NjdResultMessages.fromId(NjdMessageId.EM_ZZ9998E));

        } else if (NjdStringUtils.equals(inDto.getXJidoWariateShoriKbn(),
            CN_X_JIDO_WARIATE_SHORI_KBN.SEIKYU_KOMOKU_SEIKYU_YOTEI_TOKUTEI.getValue())
            && (NjdStringUtils.isEmpty(inDto.getJuchuKeiyakuNo()) || NjdStringUtils.isEmpty(inDto.getSeikyuShiharaiCd()))) {
            throw new NjdBusinessException(NjdResultMessages.fromId(NjdMessageId.EM_ZZ9998E));

        }

        // カレンダ年月日
        LocalDate calendar = inDto.getBusinessDate().getCalendarYmd();

        // 入力DTO．自動割当処理区分 ≠ 「自動割当設定を利用する」の場合
        if (!NjdStringUtils.equals(inDto.getXJidoWariateShoriKbn(), CN_X_JIDO_WARIATE_SHORI_KBN.JIDOWARIATE_SETTEI_RIYO.getValue())) {

            // 選定候補明細リスト を作成
            List<ED3503T_TBL> kohoEd3503Ttbls = getKohoEd3503Ttbls(inDto, calendar);

            if (!NjdCollectionUtils.isEmpty(kohoEd3503Ttbls)) {

                // 選定候補明細リスト内の最大税抜金額
                Long maxZeinukiAmt = kohoEd3503Ttbls.stream().mapToLong(ED3503T_TBL::getZeinukiSeikyuAmt).max().getAsLong();

                // 選定候補明細リストより、最大税抜金額であるレコードを抽出
                List<ED3503T_TBL> extractKohos = kohoEd3503Ttbls.stream().filter(s -> maxZeinukiAmt.equals(s.getZeinukiSeikyuAmt()))
                    .collect(Collectors.toList());

                // 対象請求書テンプレートの特定
                ED3969M_TBL taishoEd3969Mtbl = getTaishoEd3969Mtbl(extractKohos, calendar);

                outDto.setEd3969mTbl(taishoEd3969Mtbl);

                return outDto;
            }
        }

        // 自動割当先として設定されている請求書テンプレートキー情報 取得
        ED3501T_TBL ed3501Ttbl = selectJidoWariate(inDto.getKaishaCd(), inDto.getKanrenJuchuKeiyakuNo());

        // 請求書テンプレート情報 取得
        List<ED3969M_TBL> ed3969Mtbls = selectSeikyushoTemplate(ed3501Ttbl.getKaishaCd(), ed3501Ttbl.getSeikyusakiTorihikisakiCd(),
            ed3501Ttbl.getSeikyusakibetsuTemplateSn(), calendar);

        outDto.setEd3969mTbl(ed3969Mtbls.get(0));
        return outDto;
    }

    /**
     * <pre>
     * 請求書テンプレート選定候補の明細を取得する。
     *
     * </pre>
     *
     * @param inDto 入力DTO
     * @param calendar 業務カレンダー日付
     * @return 選定候補明細リスト
     */
    private List<ED3503T_TBL> getKohoEd3503Ttbls(ESNZZ19JidoWratSikyshTemplateSearchInDTO inDto, LocalDate calendar) {

        // 選定候補明細リスト を作成
        List<ED3503T_TBL> kohoEd3503Ttbls = new ArrayList<>();

        // 対象の請求管理明細情報を検索
        List<ED3503T_TBL> ed3503Ttbls = selectKohoMeisai(inDto.getKaishaCd(), inDto.getKanrenJuchuKeiyakuNo(), inDto.getJuchuKeiyakuNo(),
            inDto.getSeikyuShiharaiCd(), inDto.getXJidoWariateShoriKbn());

        // 対象の請求管理明細情報より、受注契約番号と請求支払コードの組み合わせ別でMapを作成
        Map<String, List<ED3503T_TBL>> kohoEd3503TtblMap = ed3503Ttbls.stream()
            .collect(Collectors.groupingBy(s -> s.getJuchuKeiyakuNo() + s.getSeikyuShiharaiCd()));

        // 受注契約番号と請求支払コードの組み合わせ分、処理を繰り返す
        for (Entry<String, List<ED3503T_TBL>> kohoEntry : kohoEd3503TtblMap.entrySet()) {

            // 請求書表示開始年月日を降順で並び替え
            kohoEntry.getValue().sort(Comparator.comparing(ED3503T_TBL::getSeikyushoHyojiKaishiYmd, Comparator.reverseOrder()));

            // 先頭レコードの連番と取引先コードを使って3969Mを取得(Entity)
            WhereList<ED3969M_TBLColumn> whereList = ed3969m.createWhereList();
            // 会社コード
            whereList.add(ED3969M_TBLColumn.KAISHA_CD, SqlOperator.EQUAL, kohoEntry.getValue().get(0).getKaishaCd());
            // 請求先取引先コード
            whereList.add(ED3969M_TBLColumn.SEIKYUSAKI_TORIHIKISAKI_CD, SqlOperator.EQUAL,
                kohoEntry.getValue().get(0).getSeikyusakiTorihikisakiCd());
            // 請求先別テンプレート連番
            whereList.add(ED3969M_TBLColumn.SEIKYUSAKIBETSU_TEMPLATE_SN, SqlOperator.EQUAL,
                kohoEntry.getValue().get(0).getSeikyusakibetsuTemplateSn());
            // 適用終了年月日
            whereList.add(ED3969M_TBLColumn.TEKIYO_SHURYO_YMD, SqlOperator.GREATER_THAN_EQUAL, calendar);
            // DB検索：請求書テンプレートマスタ
            List<ED3969M_TBL> ed3969Mtbl = ed3969m.select(whereList);

            // レコード無しの場合、処理しない
            if (ed3969Mtbl.isEmpty()) {
                continue;
            }

            // 最新請求書表示開始年月日のレコード
            LocalDate latestKaishiYmd = kohoEntry.getValue().get(0).getSeikyushoHyojiKaishiYmd();

            for (ED3503T_TBL koho : kohoEntry.getValue()) {

                // 対象レコードの請求書表示開始年月日が、最新請求書表示開始年月日と同様であった場合
                if (latestKaishiYmd.equals(koho.getSeikyushoHyojiKaishiYmd())) {

                    // 選定候補明細リストに追加
                    kohoEd3503Ttbls.add(koho);

                } else {
                    break;
                }
            }
        }

        return kohoEd3503Ttbls;
    }

    /**
     * <pre>
     * 対象請求書テンプレートの特定する。
     *
     * </pre>
     *
     * @param extractKohos 抽出結果選定候補明細リスト
     * @param calendar カレンダ年月日
     * @return
     */
    private ED3969M_TBL getTaishoEd3969Mtbl(List<ED3503T_TBL> extractKohos, LocalDate calendar) {

        List<ED3969M_TBL> ed3969Mtbls = new ArrayList<>();

        for (ED3503T_TBL extractKoho : extractKohos) {

            // 対象請求書テンプレートマスタが空の場合
            if (ed3969Mtbls.isEmpty()) {

                // 検索結果を設定
                ed3969Mtbls.addAll(selectSeikyushoTemplate(extractKoho.getKaishaCd(), extractKoho.getSeikyusakiTorihikisakiCd(),
                    extractKoho.getSeikyusakibetsuTemplateSn(), calendar));

                // 対象請求書テンプレートマスタに設定されてる情報と抽出選定候補明細のテンプレート情報が異なる場合
            } else if (!(NjdStringUtils.equals(ed3969Mtbls.get(0).getKaishaCd(), extractKoho.getKaishaCd())
                && NjdStringUtils.equals(ed3969Mtbls.get(0).getSeikyusakiTorihikisakiCd(), extractKoho.getSeikyusakiTorihikisakiCd())
                && NjdStringUtils.equals(ed3969Mtbls.get(0).getSeikyusakibetsuTemplateSn(), extractKoho.getSeikyusakibetsuTemplateSn()))) {

                // 検索結果を設定 // 検索結果を設定
                ed3969Mtbls.addAll(selectSeikyushoTemplate(extractKoho.getKaishaCd(), extractKoho.getSeikyusakiTorihikisakiCd(),
                    extractKoho.getSeikyusakibetsuTemplateSn(), calendar));

            }
        }

        // 検索結果が1件のみの場合
        if (ed3969Mtbls.size() == 1) {
            return ed3969Mtbls.get(0);

        }

        // 最古の登録タイムスタンプ
        LocalDateTime oldestRegstTmstmp = ed3969Mtbls.stream().map(ED3969M_TBL::getRegstTmstmp).min(Comparator.naturalOrder()).get();

        // 最古の登録タイムスタンプで抽出した請求書テンプレート情報
        List<ED3969M_TBL> extractEd3969Mtbls = ed3969Mtbls.stream().filter(s -> s.getRegstTmstmp() == oldestRegstTmstmp)
            .sorted(Comparator.comparing(ED3969M_TBL::getSeikyushoTemplateNo, Comparator.naturalOrder())).collect(Collectors.toList());

        return extractEd3969Mtbls.get(0);

    }

    /**
     * <pre>
     * 選定候補明細リストを検索する。
     *
     * </pre>
     *
     * @param kaisha 会社コード
     * @param kanrenNo 関連受注契約番号
     * @param no 受注契約番号
     * @param cd 請求支払コード
     * @param shoriKbn 自動割当処理区分
     * @return 選定候補明細リスト
     */
    private List<ED3503T_TBL> selectKohoMeisai(String kaisha, String kanrenNo, String no, String cd, String shoriKbn) {

        WhereList<ED3503T_TBLColumn> whereList = ed3503t.createWhereList();

        // 会社コード
        whereList.add(ED3503T_TBLColumn.KAISHA_CD, SqlOperator.EQUAL, kaisha);

        // ========================================================
        // CN_自動割当処理区分．契約の請求予定から特定する の場合
        // ========================================================
        if (NjdStringUtils.equals(shoriKbn, CN_X_JIDO_WARIATE_SHORI_KBN.KEIYAKU_SEIKYU_YOTEI_TOKUTEI.getValue())) {

            // 関連受注契約番号
            whereList.add(ED3503T_TBLColumn.KANREN_JUCHU_KEIYAKU_NO, SqlOperator.EQUAL, kanrenNo);
            // 長期契約料金継続請求区分
            whereList.addIn(ED3503T_TBLColumn.CHK_KIYK_RYKN_KIZK_SIKY_KBN,
                Arrays.asList(CN_CHK_KIYK_RYKN_KIZK_SIKY_KBN.KEIZOKU_RYOKIN_GETSUGAKU.getValue(),
                    CN_CHK_KIYK_RYKN_KIZK_SIKY_KBN.KEIZOKU_RYOKIN_NENGAKU.getValue()));

            // ============================================================
            // CN_自動割当処理区分．請求項目の請求予定から特定する の場合
            // ============================================================
        } else if (NjdStringUtils.equals(shoriKbn, CN_X_JIDO_WARIATE_SHORI_KBN.SEIKYU_KOMOKU_SEIKYU_YOTEI_TOKUTEI.getValue())) {

            // 受注契約番号
            whereList.add(ED3503T_TBLColumn.JUCHU_KEIYAKU_NO, SqlOperator.EQUAL, no);
            // 請求支払コード
            whereList.add(ED3503T_TBLColumn.SEIKYU_SHIHARAI_CD, SqlOperator.EQUAL, cd);

        }

        // 契約料金請求先区分
        whereList.add(ED3503T_TBLColumn.KEIYAKU_RYOKIN_SEIKYUSAKI_KBN, SqlOperator.EQUAL,
            CN_KEIYAKU_RYOKIN_SEIKYUSAKI_KBN.KEIYAKUSHA.getValue());
        // 分割済フラグ
        whereList.add(ED3503T_TBLColumn.BUNKATSUZUMI_FLG, SqlOperator.EQUAL, CN_BUNKATSUZUMI_FLG.FALSE.getValue());
        // 合算先フラグ
        whereList.add(ED3503T_TBLColumn.GASSANSAKI_FLG, SqlOperator.EQUAL, CN_GASSANSAKI_FLG.FALSE.getValue());

        OrderByList<ED3503T_TBLColumn> orderByList = ed3503t.createOrderByList();
        // 請求書表示開始年月日（降順）
        orderByList.add(ED3503T_TBLColumn.SEIKYUSHO_HYOJI_KAISHI_YMD, SqlOrderBy.DESC);

        // DB検索：請求管理明細テーブル
        return ed3503t.select(whereList, orderByList);

    }

    /**
     * <pre>
     * 自動割当先として設定されている請求情報契約管理テーブルを取得する。
     *
     * </pre>
     *
     * @param outDto 出力DTO
     * @param kaisha 会社コード
     * @param cd 受注契約番号
     * @return 請求情報契約管理テーブル
     */
    private ED3501T_TBL selectJidoWariate(String kaisha, String cd) {

        WhereList<ED3501T_TBLColumn> whereList = ed3501t.createWhereList();
        // 会社コード
        whereList.add(ED3501T_TBLColumn.KAISHA_CD, SqlOperator.EQUAL, kaisha);
        // 受注契約番号
        whereList.add(ED3501T_TBLColumn.JUCHU_KEIYAKU_NO, SqlOperator.EQUAL, cd);
        // 自動割当フラグ
        whereList.add(ED3501T_TBLColumn.JIDO_WARIATE_FLG, SqlOperator.EQUAL, CN_JIDO_WARIATE_FLG.TRUE.getValue());

        // DB検索：請求情報契約管理テーブル
        return ed3501t.select(whereList).get(0);
    }

    /**
     * <pre>
     * 請求書テンプレート情報を取得する。
     *
     * </pre>
     *
     * @param kaisha 会社コード
     * @param cd 請求先取引先コード
     * @param sn 請求先別テンプレート連番
     * @param ymd カレンダ年月日
     * @return 請求書テンプレートマスタ
     */
    private List<ED3969M_TBL> selectSeikyushoTemplate(String kaisha, String cd, String sn, LocalDate ymd) {

        WhereList<ED3969M_TBLColumn> whereList = ed3969m.createWhereList();
        // 会社コード
        whereList.add(ED3969M_TBLColumn.KAISHA_CD, SqlOperator.EQUAL, kaisha);
        // 請求先取引先コード
        if (NjdStringUtils.isNotEmpty(cd)) {
            whereList.add(ED3969M_TBLColumn.SEIKYUSAKI_TORIHIKISAKI_CD, SqlOperator.EQUAL, cd);
        }
        // 請求先別テンプレート連番
        if (NjdStringUtils.isNotEmpty(sn)) {
            whereList.add(ED3969M_TBLColumn.SEIKYUSAKIBETSU_TEMPLATE_SN, SqlOperator.EQUAL, sn);
        }
        // 適用開始年月日
        whereList.add(ED3969M_TBLColumn.TEKIYO_KAISHI_YMD, SqlOperator.LESS_THAN_EQUAL, ymd);
        // 適用終了年月日
        whereList.add(ED3969M_TBLColumn.TEKIYO_SHURYO_YMD, SqlOperator.GREATER_THAN_EQUAL, ymd);
        // 請求書テンプレート申請状況区分
        whereList.addIn(ED3969M_TBLColumn.SIKYSH_TEMPLATE_SHNSI_JKY_KBN, Arrays
            .asList(CN_SIKYSH_TEMPLATE_SHNSI_JKY_KBN.SHINSEI_FUYO.getValue(), CN_SIKYSH_TEMPLATE_SHNSI_JKY_KBN.SHONIN_ZUMI.getValue()));

        // DB検索：請求書テンプレートマスタ
        return ed3969m.select(whereList);
    }
}
