import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class TableInfo {
	String filename;
	String tableName;
	String CSVPath;
	String SQLPath;

	List<String> CSVFiles = new ArrayList<String>();
	List<String> CSVCols  = new ArrayList<String>();
	List<String> SQLFiles = new ArrayList<String>();
	Map <String, List<String>> SQLColumns = new  LinkedHashMap<>();


	public boolean ReadConfig() {
		this.filename = "Config.sys";
		File file = new File(filename);

		BufferedReader bufferedReader;
		try {
			bufferedReader = new BufferedReader(new FileReader(file));
			String line;
			try {
				while ((line = bufferedReader.readLine()) != null) {
					if (line.toLowerCase().contains("csvpath=")) {
						this.CSVPath = line.toLowerCase().replace("csvpath=", "").trim();
					} else if (line.toLowerCase().contains("sqlpath=")) {
						this.SQLPath = line.toLowerCase().replace("sqlpath=", "").trim();
					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		} catch (FileNotFoundException e) {
			System.out.println("Configuration file (Config.sys) not found");
			return false;
		}
		return true;
	}

	public boolean GetFiles(String path, String destination) {

		try {
			// Empty previous content of TableInfo.csv
			BufferedWriter writer = new BufferedWriter(new FileWriter("TableInfo.csv"));
			writer.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try {
			File directoryPath = new File(path);
			String[] files = directoryPath.list();
			if (files == null) {
				System.out.println("Can not find files in " + path);
				return false;
			}
			if (files.length == 0) {
				System.out.println("No files in " + path);
				return false;
			}
			if (destination == "SQLFiles") {
				for (String currentFile : files)
					if (currentFile.toLowerCase().endsWith(".sql")) {
						this.SQLFiles.add(currentFile);
						if (!ReadSQLCols(currentFile)) {
							System.out.println("Error gathering columns in " + currentFile);
						}
					}
			} else {
				for (String currentFile : files)
					if (currentFile.toLowerCase().endsWith(".csv"))
						this.CSVFiles.add(currentFile);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean ReadSQLCols(String SQLFile) {

		File file = new File(this.SQLPath, SQLFile);
		List<String> columns =  new ArrayList<String>() ;
		String columnInfo = "";

		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter("TableInfo.csv", true));

			// Creating an object of BufferedReader class
			BufferedReader bufferedReader;
			try {
				bufferedReader = new BufferedReader(new FileReader(file));
				String st;
				String columnName;
				// Condition holds true till
				// there is character in a string
				try {
					boolean readingColumn = false;
					while ((st = bufferedReader.readLine()) != null) {
						if (readingColumn) {
							if (st.contains(",CONSTRAINT") || st.contains(",)") || st.trim().charAt(0)== ')') {
								columnInfo = tableName + "," + columnInfo + "\n";
								writer.append(columnInfo);
								writer.close();
								System.out.println("Done gathering " + tableName + " columns");
								SQLColumns.put(tableName, columns);
								return true;
							} else {
								// Print the string
								columnName = st.replace(",", "").trim();
								try {
									columnName = columnName.substring(0, columnName.indexOf(" "));
									columns.add(columnName);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									System.out.println(columnName + "|" + st);
									e.printStackTrace();
								}
								if (columnInfo=="")
									columnInfo = columnName;
								else
									columnInfo = columnInfo + "," + columnName;
							}
						} else {
							if (st.contains("CREATE TABLE")) {
								this.tableName = st.replace("CREATE TABLE", "").replace("(", "").trim();
								readingColumn = true;
							}

						}
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			} catch (FileNotFoundException e) {
				System.out.println("File :" + filename + " not found");
			}
		} catch (IOException e1) {
			System.out.println("Error adding file TableInfo.csv");
			e1.printStackTrace();
		}
		return true;
	}

	public boolean GetSQLMatch(String CSVFile) {
		if (!ReadCSVCols(CSVFile)) {
			System.out.println("Reading CSV columns of " + CSVFile + " failed");
		}
		String NearestMatch = "";
		int nearMatchCols = 0;
		for (Entry<String, List<String>> SQLInfo : SQLColumns.entrySet()) {


			if (SQLInfo.getValue().size() == this.CSVCols.size()) {
				if (SQLInfo.getValue().containsAll(this.CSVCols)) {
					System.out.println("Match SQL : " + SQLInfo.getKey());
					return true;
				}
			} else if (SQLInfo.getValue().size() < this.CSVCols.size()) {
				if (this.CSVCols.containsAll(SQLInfo.getValue())) {
					if (this.CSVCols.size()> nearMatchCols) {
						nearMatchCols = this.CSVCols.size();
						//matchCol =  (this.CSVCols.size() - SQLInfo.getValue().size());
						NearestMatch = SQLInfo.getKey() + "(CSV have " + (this.CSVCols.size() - SQLInfo.getValue().size()) + " more columns";
					}
				}
			} else if (SQLInfo.getValue().size() > this.CSVCols.size()) {
				if (SQLInfo.getValue().containsAll(this.CSVCols)) {
					if (SQLInfo.getValue().size()> nearMatchCols) {
						nearMatchCols = SQLInfo.getValue().size();
						NearestMatch = SQLInfo.getKey() + "(SQL have " + (SQLInfo.getValue().size() - this.CSVCols.size()) + " more columns";
					}
				}
			}
		}
		if (NearestMatch != "") {
			System.out.println("Nearest Match : " + NearestMatch);
			return true;
		}
			
		// Detail scan
		nearMatchCols = 0;

		for (Entry<String, List<String>> SQLInfo : SQLColumns.entrySet()) {
			int matchCol = 0;			
			for (String column : this.CSVCols) {
				if (SQLInfo.getValue().contains(column)) {
					matchCol++;
				}
			}
			if (matchCol > nearMatchCols) {
				nearMatchCols = matchCol;
				NearestMatch = SQLInfo.getKey();
			}
		}
		System.out.println("Nearest Match : " + NearestMatch + " " + nearMatchCols + " columns match out of " + this.CSVCols.size() + " columns");
		return true;

	}

	public boolean ReadCSVCols(String CSVFile) {
		File file = new File(this.CSVPath, CSVFile);
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String st;
			try {
				st = br.readLine();
				if (st.contains("	")) {
					this.CSVCols = Arrays.asList(st.split("\\t"));
				} else if (st.contains(",")) {
					this.CSVCols = Arrays.asList(st.split(","));
				} else
					System.out.println("Unknown CSV file structure");
				System.out.println(st.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			System.out.println("File :" + filename + " not found");
		}
		return true;
	}

	public boolean CompareCol(String CSVFile, String SQLFile) {
		this.filename = "ED0517T_TBL.sql";
		// File path is passed as parameter
		File file = new File(filename);
		String columnInfo = "";
		List<String> columns =  new ArrayList<String>() ;
		// Creating an object of BufferedReader class
		BufferedReader br;
		try {
			br = new BufferedReader(new FileReader(file));
			String st;
			// Condition holds true till
			// there is character in a string
			try {
				boolean readingColumn = false;
				while ((st = br.readLine()) != null) {
					if (readingColumn) {
						if (st.contains(",CONSTRAINT")) {
							columnInfo = tableName + "," + columnInfo;
							return true;
						} else {
							// Print the string
							String columnName = st.replace(",", "").trim();
							columnName = columnName.substring(0, columnName.indexOf(" "));
							columns.add(columnName);
							if (columnInfo==null)
								columnInfo = columnName;
							else
								columnInfo = columnInfo + "," + columnName;
						}
					} else {
						if (st.contains("CREATE TABLE")) {
							this.tableName = st.replace("CREATE TABLE", "").replace("(", "").trim();
							readingColumn = true;
						}

					}
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			System.out.println("File :" + filename + " not found");
		}
		return true;
	}


}
