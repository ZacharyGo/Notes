-- ED9124T_TBL ("申請承認業務紐付テーブル")

SELECT 
    ED9124T_TBL.*
FROM 
    ED9124T_TBL -- 申請承認業務紐付テーブル
WHERE
    KAISHA_CD = '10000'
    AND SHNSI_SHNN_HMZK_TABLE_ID = 'ED3804T_TBL';
